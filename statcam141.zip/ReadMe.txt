NOAA Fisheries Toolbox
Statistical Catch at Age Model (StatCAM)
Beta Version 1.4.1

Includes graphic interface version 1.4.1 (5/1/08) and calculation engine version 1.4.1 (4/1/08).


1. INSTALLATION
2. GETTING STARTED
3. USEFUL FEATURES
4. GETTING HELP
5. VERSION CHANGES


=== 1. INSTALLATION =====================

StatCAM can be installed on Windows 95, Windows 98, Windows 2000, and Windows XP.

If you have a previous version installed on your computer, it is recommended that you uninstall the old version before proceeding.

To begin the installation process, double-click on the file "setup.exe". Follow the prompts in the installation dialogue.

The default directory is C:\NFT\STATCAM. If you wish to install StatCAM in a different directory, please select a directory which does not contain spaces.

During the installation, you may encounter the message: "The existing file is newer than the one Setup is trying to install. It is recommended that you keep the existing file." This simply indicates that you have a more recent copy of a helper file needed to run the program. At the prompt, "Do you want to keep the existing file?" click "Yes" to keep the file that is on your computer.  Clicking "No" will overwrite the file with the one supplied by the installation package. It is generally recommended that you keep the file that is newer.

If you install StatCAM on a remote or network drive, be aware that a recent Windows security update prevents the help file (STATCAMHELP.chm) from being displayed correctly if opened from a remote computer. This has the effect of disabling the context sensitive help feature (see section 4. Getting Help, below, for more information on context sensitive help). However, you can still view the help file manually if you copy the file (STATCAMHELP.chm) to your computer's hard drive and then double-click on the file to open it.


=== 2. GETTING STARTED ==================

Open the application by going to the Start Menu, selecting Programs, then selecting NFT, and finally selecting StatCAM.

You may store input and output files in any directory that does not contain spaces. File names also must not contain spaces.

Sample input files are provided in the "Examples" folder, which is located in the directory where you installed StatCAM (e.g., C:\NFT\STATCAM\Examples\).

StatCAM is designed to display input and output in different "windows" or panels which hide behind each other in the main display. When using StatCAM, if multiple windows are open, simply go to the Window Menu (located in the top row of the StatCAM application) and select the desired item to bring it to the front.

StatCAM has a group of values called General Parameters, which are displayed on the first tab of the Input Data form. General Parameters define the dimensions of the different vectors and matrices of data that the model will need. The General Parameters may include values such as the first and last year of data, the number of ages in the data data, how many surveys there are, etc. Note that reducing the value of a General Parameter will re-size the grids and delete any data that doesn't fall within the new parameter range.


=== 3. USEFUL FEATURES ==================

Data in input grids can be edited similar to that of common spreadsheet software. (See the Editing Grid Data topic in the help file.) Data can also be entered into grids by copying sections of data from a spreadsheet or text file and then pasting the data into the grid.

Log files recording error messages and regular output from the calculation engine are created automatically when the model is run and can be viewed from within the graphic interface. If the default file viewer included in the program is not to your liking, you can select a program such as Microsoft Word or Notepad to view the files with.

Plots can be easily customizable and can be saved to your computer as individual files or in a single file (called a Plot Collection).

For some plots with drop-down or list boxes, you can achieve an animated flip-book effect by using the up or down arrow keys on your keyboard to rapidly select the next item in the list.

Before exiting the program, you will automatically be prompted to save your input files to prevent accidental loss of data. You can turn these notifications off if they become bothersome.

If you need to modify the default number of items in the General Parameters list boxes, you can change the range for these items by going to the Options menu and selecting "General Parameter Ranges".

For more details on how to use these and other features, please see the help file "STATCAMHELP.chm".


=== 4. GETTING HELP =====================

Context sensitive help is available by pressing the F1 key on your keyboard. Pressing F1 brings up the help pages, and in many cases goes directly to the topic relating to what is currently displayed on your screen.

You can also access the help pages from the Help menu of the StatCAM application. Or you can manually open the file by navigating to the directory where StatCAM is installed (typically C:\NFT\STATCAM) and double-clicking on the help file "STATCAMHELP.chm".

A separate reference manual describing model methods in detail is also available. You can either access the manual from the Help menu of the graphic interface or open it up manually. The reference manual (statcam.pdf) is located in the installation directory. Adobe Acrobat Reader is required to view the reference manual. If you don't have Adobe Acrobat Reader installed on your computer you may install it for free at  http://www.adobe.com/products/acrobat/readstep2.html.

For answers to Frequently Asked Questions about the NOAA Fisheries Toolbox, please visit the NOAA Fisheries Toolbox website, http://nft.nefsc.noaa.gov/, and select the Frequently Asked Questions topic.

For user support, please contact:

Alan Seaver
NOAA Fisheries
Northeast Fisheries Science Center
166 Water Street
Woods Hole, MA  02543  USA

Phone: 508-495-2024
Fax: 508-495-2393
email: NFToolbox.support@noaa.gov

Contact times are M-F, 8:00 AM to 5:00 PM (Eastern Time). When e-mailing a support problem please attach the problem input files and note which version you are using.


=== 5. VERSION CHANGES ==================

StatCAM Version 1.4.1 Beta (5/1/08)
- Replaces StatCAM Version 1.3.1 Beta.
- Includes graphic interface version 1.4.1 (5/1/08) and calculation engine version 1.4.1 (4/8/08).
Calculation Engine Changes:
- various; see reference manual
Graphic Interface changes:
- New Feature: Ability to set the General Parameters by simply clicking on the desired value from a list of choices.
- New Feature: A new grid editing tool. The new tool streamlines data entry when typing from the keyboard and when pasting data from the Windows clipboard. Shortcut key combinations (e.g. CTRL-C for Copy, CTRL-V for Paste, etc.) are available for common grid editing functions. A menu of common grid editing functions is accessible by right-clicking anywhere on the grid.


Beta Version 1.3.1 (September 2006)
Replaces Beta Version 1.3
- Recruitment year is now set to Start Year - Number of Ages +1 (Formerly +2).
- Added the ability to capture error messages and output to the command window to a log file and have the log file viewed in the graphical interface.
- Upgraded Plotting Package.


=========================================